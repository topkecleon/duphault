#!/bin/sh
zip -r duphault.zip * -x .git

