duphault
========

dupie's modified look of Minecraft


A slightly modified Minecraft resource pack to make things look better and more consistent. Also includes a custom font which is smoother than the default. (Custom fonts can be enabled through the installation of OptiFine, a graphical optimization modification found at optifine.net/)
