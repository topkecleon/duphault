# duphault

## Drew's modified look of Minecraft

Modification of the default Minecraft resource pack to make things smoother and more consistent. Also includes a slightly modified, more elegant font and some CTM support.

These textures are modified versions of those provided by Mojang; do not make commercial use of them.
