duphault
========

dupie's modified look of Minecraft


A slightly modified Minecraft resource pack to make things look better and more
consistent. It also includes a slightly modified font and some CTM support.

These textures are merely modified versions of those provided by Mojang; do not
make commercial use of them or distribute them to people who have not purchased
a Minecraft license from Mojang.
