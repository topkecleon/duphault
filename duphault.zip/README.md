duphault
========

dupie's modified look of Minecraft


A slightly modified Minecraft resource pack to make things look better and more consistent.
It also includes a slightly modified font and minimal CTM support.
